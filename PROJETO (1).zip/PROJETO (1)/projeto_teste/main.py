from tkinter import *
from tela_registro import Cadastro
import pickle
from tela import Application
from tela_produtos import Compras

class Janela():
    def __init__(self, mestre):

        self.dicio_usuarios = {}
        

        self.c1 = Frame(mestre)
        self.c1["padx"] = 100
        self.c1["pady"] = 10
        self.c1.pack()

        self.titulo = Label(self.c1, text="Dados do usuário")
        self.titulo["font"] = ("Arial", "10", "bold")
        self.titulo.pack()

        self.c2 = Frame(mestre)
        self.c2.pack()

        self.t2 = Label(self.c2, text="Nome")
        self.t2.pack(side=LEFT)
        self.l2 = Entry(self.c2)
        self.l2.pack(side=LEFT)

        self.c3 = Frame(mestre)
        self.c3.pack()
        self.t3 = Label(self.c3, text="Senha")
        self.t3.pack(side=LEFT)
        self.l3 = Entry(self.c3)
        self.l3.pack(side=LEFT)

        self.c4 = Frame(mestre)
        self.c4.pack()
        self.botao = Button(self.c4, text='Login')
        self.botao["command"] = self.login
        self.botao.pack()
        
        self.c5 = Frame(mestre)
        self.c5.pack()
        self.botao = Button(self.c5, text='não tem conta?')
        self.botao["command"] = Cadastro
        self.botao.pack()

        self.mensagem = Label(self.c4, text="")
        self.mensagem.pack()

    def login(self):
        nome = self.l2.get()
        senha = self.l3.get()

        arquivo = open('lista_usuarios.txt', 'rb')
        retorno = pickle.load(arquivo)

        for i in retorno:
            if i == nome:
                if retorno[i] == senha:
                    self.mensagem['text'] == 'Deu certo!'
                    Compras
                else:
                    self.mensagem['text'] == 'Senha invalida!'
                    break
            else:
                continue
        self.mensagem['text'] = 'Refaça login'



        
        

raiz = Tk()
Janela(raiz)
raiz.mainloop()