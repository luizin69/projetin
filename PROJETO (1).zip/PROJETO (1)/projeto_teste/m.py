import tkinter as tk
from tkinter import messagebox

def mostrar_mensagem():
    messagebox.showinfo("Título da Mensagem", "Esta é uma mensagem de exemplo.")

# Criar a janela principal
janela = tk.Tk()
janela.title("Exemplo de MessageBox")

# Criar um botão que ao ser clicado exibirá a messagebox
botao = tk.Button(janela, text="Mostrar Mensagem", command=mostrar_mensagem)
botao.pack(padx=20, pady=20)

# Executar o loop principal
janela.mainloop()