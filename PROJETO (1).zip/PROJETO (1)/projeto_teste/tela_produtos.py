from tkinter import *
from tela import Application

import pickle

class Compras():
    def __init__(self):
        self.top = Toplevel()
        self.dicio_usuarios = {}
        
        self.c1 = Frame(self.top)
        self.c1["padx"] = 100
        self.c1["pady"] = 100
        self.c1.pack()

        self.titulo = Label(self.c1, text="Opções de Compra")
        self.titulo["font"] = ("Arial", "10", "bold")
        self.titulo.pack()
        
        self.c2 = Frame(self.top)
        self.c2.pack()
        self.botao = Button(self.c2, text='Taylor Swfit')
        self.botao["command"] = Application
        self.botao.pack()

        self.c3 = Frame(self.top)
        self.c3.pack()
        self.botao = Button(self.c3, text='Kanye West')
        self.botao["command"] = Application
        self.botao.pack()

        self.mensagem = Label(self.c3, text="")
        self.mensagem.pack()
