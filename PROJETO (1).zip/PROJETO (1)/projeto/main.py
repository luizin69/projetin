from tkinter import * 
from tkinter import messagebox

class Aplicativo():
    def __init__(self, mestre):

        self.c1 = Frame(mestre)
        self.c1['padx'] = 720
        self.c1['pady'] = 480
        self.c1.pack()

        self.entrada = Entry()


        self.butao = Button(self.c1, text = "Ir outra tela", command= self.mensagem)
        self.butao.pack()






        self.title = 'Tela Inicial'

        self.dicio_frames = {}

    def mensagem(self):
        messagebox.showinfo('baitola', 'baitola')


raiz = Tk()
Aplicativo(raiz)
raiz.mainloop()
