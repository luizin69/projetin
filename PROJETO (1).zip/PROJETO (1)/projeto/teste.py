import tkinter as tk

class Aplicacao(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self)
        self.title("Navegação Fluida")

        # Dicionário para armazenar os frames
        self.frames = {}

        # Criação dos frames e os adiciona ao dicionário
        for F in (PaginaInicial, PaginaA, PaginaB):
            frame = F(self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        # Exibir o frame inicial
        self.mostrar_frame(PaginaInicial)

    def mostrar_frame(self, cont, *args, **kwargs):
        # Método para trocar entre os frames
        frame = self.frames[cont]
        frame.atualizar(*args, **kwargs)
        frame.tkraise()

class PaginaInicial(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        label = tk.Label(self, text="Página Inicial")
        label.pack(pady=10, padx=10)

        # Botões para navegar entre as páginas
        botao_a = tk.Button(self, text="Ir para a Página A", command=lambda: master.mostrar_frame(PaginaA))
        botao_b = tk.Button(self, text="Ir para a Página B", command=lambda: master.mostrar_frame(PaginaB))

        botao_a.pack()
        botao_b.pack()

    def atualizar(self, *args, **kwargs):
        # Método chamado ao trocar para esta página (pode ser usado para atualizações específicas)
        pass

class PaginaA(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        label = tk.Label(self, text="Página A")
        label.pack(pady=10, padx=10)

        # Botão para voltar para a Página Inicial
        botao_voltar = tk.Button(self, text="Voltar para a Página Inicial", command=lambda: master.mostrar_frame(PaginaInicial))
        botao_voltar.pack()

    def atualizar(self, *args, **kwargs):
        # Método chamado ao trocar para esta página (pode ser usado para atualizações específicas)
        pass

class PaginaB(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        label = tk.Label(self, text="Página B")
        label.pack(pady=10, padx=10)

        # Botão para voltar para a Página Inicial
        botao_voltar = tk.Button(self, text="Voltar para a Página Inicial", command=lambda: master.mostrar_frame(PaginaInicial))
        botao_voltar.pack()

    def atualizar(self, *args, **kwargs):
        # Método chamado ao trocar para esta página (pode ser usado para atualizações específicas)
        pass

if __name__ == "__main__":
    app = Aplicacao()
    app.geometry("400x300")
    app.mainloop()
