import os
import pickle
from  tkinter import messagebox

def registrar(self):
    nome = self.l2.get()
    senha = self.l3.get()
    self.dicio_usuarios[nome] = senha

    # Grava o dicionário no arquivo
    with open('lista_usuarios.txt', 'wb') as arquivo:
        pickle.dump(self.dicio_usuarios, arquivo)

    # Verifica se o arquivo existe antes de tentar carregar
    if os.path.exists('lista_usuarios.txt'):
        with open('lista_usuarios.txt', 'rb') as arquivo1:
            teste = pickle.load(arquivo1)

            # Verifica se o nome e senha existem no dicionário
            if nome in teste and teste[nome] == senha:
                self.mensagem()
            else:
                messagebox.showerror('Caixa de Erro', 'Cadastro Inválido')
    else:
        messagebox.showinfo('Algo', 'Não está certo')
