from tkinter import *
class Registro():
    def __init__(self):
        frame = Frame()

        